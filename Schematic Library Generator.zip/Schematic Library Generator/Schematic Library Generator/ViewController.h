//
//  ViewController.h
//  Schematic Library Generator
//
//  Created by Arthur Xu on 2020/10/22.
//

#import <Cocoa/Cocoa.h>
#include "ComponentDefination.h"

@interface ViewController : NSViewController

@property (weak) IBOutlet NSTextField *sourceFilePathText;
@property (weak) IBOutlet NSTextField *outputPathText;
@property (weak) IBOutlet NSPopUpButton *ComponentTypePopupButton;
@property (weak) IBOutlet NSTextField *TransitionStatusText;


@property (readwrite, copy) NSString* sourcePath;
@property (readwrite, copy) NSString* outputPath;
@property (readwrite, copy) NSString* DCMFileAppendData;
@property (readwrite, copy) NSString* libFileAppendData;
@property (readwrite, copy) NSMutableArray* fileFixedContent;
@property (readwrite, copy) NSMutableArray* typesArray;
@property (readwrite, copy) NSString* selectedComponentType;
@property (readwrite) ComponentDrawType component;
@property (readwrite) NSInteger curLine;
@property (readwrite, copy) NSArray* settinngArray;
@property (readwrite, copy) NSMutableArray* referenceArray;

@end


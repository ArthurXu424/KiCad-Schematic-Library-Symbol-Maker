//
//  AppDelegate.h
//  Schematic Library Generator
//
//  Created by Arthur Xu on 2020/10/22.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end


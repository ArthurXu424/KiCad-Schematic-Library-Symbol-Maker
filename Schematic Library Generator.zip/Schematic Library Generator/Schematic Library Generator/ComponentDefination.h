//
//  ComponentDefination.h
//  KiCadSymbolMaker
//
//  Created by Arthur Xu on 2020/10/6.
//

#ifndef ComponentDefination_h
#define ComponentDefination_h

#define ITEM_VISIABLE @"V"
#define ITEM_INVISIABLE @"I"

#define ITEM_HORIZON_CENTER @"C"
#define ITEM_HORIZON_LEFT @"L"
#define ITEM_HORIZON_RIGHT @"R"

#define ITEM_VERTICAL_CENTER @"C"
#define ITEM_VERTICAL_TOP @"T"
#define ITEM_VERTICAL_BOTTOM @"B"

#define ITEM_ITALIC_ENABLE  @"I"
#define ITEM_ITALIC_DISABLE  @"N"

#define ITEM_BOLD_ENABLE  @"B"
#define ITEM_BOLD_DISABLE  @"N"

typedef enum ComponentType_t{
    ComponentType_CAP_CER = 0,
    ComponentType_CAP_TAN = 1,
    ComponentType_CAP_ALU = 2,
    ComponentType_RES_CHIP = 3,
    ComponentType_RES_PACK4 = 4,
    ComponentType_RES_PACK8 = 5,
    ComponentType_RES_VARIABLE = 6,
    ComponentType_RES_SHUNT = 7,
    ComponentType_RES_POTENTIOMETER = 8,
    ComponentType_IND_FIXED = 9,
    ComponentType_IND_COUPLED = 10,
    ComponentType_FUSE = 11,
    ComponentType_DIODE = 12,
    ComponentType_DIODE_SCHOTTKY = 13,
    ComponentType_DIODE_TVS = 14,
    ComponentType_DIODE_ZENER = 15,
    ComponentType_DIODE_TUNNEL = 16,
    ComponentType_LED = 17,
    ComponentType_LED_ARGB = 18,
    ComponentType_LED_CRGB = 19,
    ComponentType_LED_DUAL_ANODE = 20,
    ComponentType_LED_DUAL_CATHODE = 21,
    ComponentType_CRYSTAL_2PIN = 22,
    ComponentType_CRYSTAL_4PIN = 23,
    ComponentType_MOS_NJFET = 24,
    ComponentType_MOS_N = 25,
    ComponentType_BJT_NPN = 26,
    ComponentType_MOS_PJFET = 27,
    ComponentType_MOS_P = 28,
    ComponentType_BJT_PNP = 29,
    ComponentType_TRIAC = 30,
    ComponentType_FERRITE_BEAD = 31,
    ComponentType_ANTENNA = 32,
    ComponentType_BATTERY = 33,
    ComponentType_BUZZER = 34,
    ComponentType_SPEAKER = 35,
    ComponentType_MAX,
} ComponentType;



typedef struct ItemPeopertyType_t{
    NSString* itemID;
    NSString* itemValue;
    NSString* xPos;
    NSString* yPos;
    NSString* visiable;
    NSString* horizonType;
    NSString* verticalType;
    NSString* italic;
    NSString* bold;
    NSString* textSize;
    NSString* itemName;
}ItemPeopertyType;

typedef struct ComponentDrawType_t{
    NSString* keyArgument;
    NSString* keyword;
    NSString* description;
    NSString* footprint;
    NSString* reference;
    NSString* value;
    NSString* datasheet;
    NSString* symbolName;
    NSString* draw;
    NSString* descriptionPrefix;
    NSString* plist;
}ComponentDrawType;



#endif /* ComponentDefination_h */

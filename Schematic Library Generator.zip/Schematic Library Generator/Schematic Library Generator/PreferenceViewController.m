//
//  PreferenceViewController.m
//  Schematic Library Generator
//
//  Created by Arthur Xu on 2020/10/23.
//

#import "PreferenceViewController.h"

@interface PreferenceViewController ()

@end

@implementation PreferenceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
    super.view.window.title = @"Preference";
}

-(BOOL)writeComponentSettinng:(NSString*)reference Type:(NSString*)type Plist:(NSString*)plist Draw:(NSString*)draw DescriptionPrefix:(NSString*)descriptionPrefix KeyArgument:(NSMutableArray*)ArgumentsArray
{
    return YES;
}

@end

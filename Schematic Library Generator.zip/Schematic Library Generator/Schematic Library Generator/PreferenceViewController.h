//
//  PreferenceViewController.h
//  Schematic Library Generator
//
//  Created by Arthur Xu on 2020/10/23.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface PreferenceViewController : NSViewController

@end

NS_ASSUME_NONNULL_END
